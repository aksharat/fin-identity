# Text Finder > 2023-08-06 6:53am
https://universe.roboflow.com/school-f4lzv/text-finder-bkd6g

Provided by a Roboflow user
License: CC BY 4.0

