import os
import csv
from flask import Flask, render_template, request

app = Flask(__name__)

# Function to fetch data from CSV files
def get_customer_data(fname, lname, dob):
    csv_files = ["results_train.csv", "results_test.csv", "results_valid.csv"]
    customer_data = None
    matched_cust_id = None

    for csv_file in csv_files:
        csv_path = os.path.join(os.path.dirname(__file__), csv_file)
        with open(csv_path, "r") as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                if (
                    row["First Name"].lower() == fname.lower()
                    and row["Last Name"].lower() == lname.lower()
                    # and row["DOB"] == dob  # Use the appropriate DOB column
                ):
                    matched_cust_id = row["Cust ID"]
                    customer_data = {
                        "first_name": row["First Name"],
                        "middle_name": row["Middle Name"],
                        "last_name": row["Last Name"],
                        "prefix": row["Prefix"],
                        "suffix": row["Suffix"],
                        "address_line_1": row["Address Line 1"],
                        "address_line_2": row["Address Line 2"],
                        "city": row["City"],
                        "state": row["State"],
                        "zip": row["Zip"],
                        "dob": row["DOB"],  # Use the appropriate DOB column
                        # Add other fields as needed
                    }
                    break

            if customer_data:
                break

    return customer_data, matched_cust_id

@app.route("/", methods=["GET", "POST"])
def index():
    customer_data = None
    matched_cust_id = None
    if request.method == "POST":
        fname = request.form.get("fname")
        lname = request.form.get("lname")
        dob = request.form.get("dob")
        customer_data, matched_cust_id = get_customer_data(fname, lname, dob)
    return render_template("index.html", customer_data=customer_data, matched_cust_id=matched_cust_id)

if __name__ == "__main__":
    app.run(debug=True)

